const express=require('express');
const mysql=require('mysql');
//Create a connection
const db=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'Jeel@mysql',
    database: 'crudmysql'
});
//Connect
db.connect((err)=>{
    if(err){
        throw(err);
    }
    console.log("Mysql connected sucessfully")
})

const app=express();
//Create the database
app.get('/createdb',(req,res)=>{
    let sql='CREATE DATABASE CRUDMYSQL';
    db.query(sql,(err,result)=>{
        if(err) throw err;
        res.send("Database created sucesfully")
        console.log(result);
    })
})

//Crete a table

app.get('/createtable',(req,res)=>{
    let sql='CREATE TABLE EMP_DETAILS(id int AUTO_INCREMENT,name VARCHAR(50), designation VARCHAR(50), mobile VARCHAR(50), email VARCHAR(50),PRIMARY KEY(id))';
    db.query(sql,(err,result)=>{
        if(err)
        throw(err);
        console.log(result);
        res.send("Post table created...");
    })
})
//Insert values
app.get('/addentries',(req,res)=>{
  let sql='INSERT INTO EMP_DETAILS(name,designation,mobile,email) VALUES ?';
  let VALUES=[
      ['Vivek Mehta','project manager','942612345','vivek@211'],
      ['Kaushal Popat','senior developer','942655545','kaushal@211'],
      ['Yash Purohit','tester','940012345','yash@211'],
      ['Digant Purani','quality manager','947812345','digant@211'],
      ['Tridal Shah','HR ','942696845','tridal@211']

  ];
  let query=db.query(sql,[VALUES],(err,result)=>{
      if(err)
      throw(err);
      console.log("Numbers of records inserted: "+result.affectedRows);
  });

});
//Update Employee
app.get('/updateemployee1',(req,res)=>{
    let sql="UPDATE EMP_DETAILS SET name='Vivek patel'WHERE ID=1";
   
    let query=db.query(sql,(err,result)=>{
        if(err)
        throw(err);
        console.log(result);
        res.send('Employee UPDATED  Sucessfully');
    });
       
});
//Delete an employee
app.delete('/employee/:id',(req,res)=>{
    db.query('Delete FROM EMP_Details WHERE id= ?',[req.params.id],(err,result)=>{
        if(err)
        throw(err);
        console.log(result);
        res.send('Deleted  Sucessfully');
    });
});

//Insert an employee
app.get('/addemployee',(req,res)=>{
    let sql='INSERT INTO EMP_DETAILS(name,designation,mobile,email) VALUES ?';
    let VALUES=[
        ['Dipen Mehta','General manager','942777345','dipen@211']
    ]
    let  query=db.query(sql,[VALUES],(err,result)=>{
        if(err)
        throw(err);
        console.log(result);
        res.send('Employee added  Sucessfully');
    });
       
});


//Show the table 
app.get('/showemployees',(req,res)=>{
    db.query('SELECT * FROM EMP_DETAILS',(err,result)=>{
        if(err)
        throw(err);
        console.log(result);
        res.send(result);
    });
});

app.listen(3000,()=>{
    console.log("Server listning on port 3000");
})