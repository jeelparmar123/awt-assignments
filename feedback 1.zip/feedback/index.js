const express =require('express');
const mysql=require('mysql');
//create a connection 
const db=mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Jeel@mysql',
    database: 'feedbackapp'
});
//connect
db.connect((err)=>{
    if(err){
        throw err;
    }
    console.log("Mysql connected successfully.....")
})

const app=express();
//create database
app.get('/createdb',(req,res)=>{
    let sql='CREATE DATABASE feedbackapp';
    db.query(sql,(err,result)=>{
        if(err)throw err;
        res.send("Database created successfully....");
        console.log(result);
    })
})

app.get('/createtblSemester',(req, res)=>{
    let sql='CREATE TABLE TBLSEMESTER(semID VARCHAR(10),Semester VARCHAR(10),PRIMARY KEY(semID))';
    db.query(sql,(err,result)=>{
        if(err)
        throw err;
        console.log(result);
        res.send("Table created successfully.....");
    })
})

app.get('/createtblSubjectinfo',(req, res)=>{
    let sql='CREATE TABLE TBLSUBJECTINFO(subID VARCHAR(10),SubjectCode VARCHAR(10),SubjectName VARCHAR(50),semID VARCHAR(10),PRIMARY KEY (subID),FOREIGN KEY (semID) REFERENCES tblSemester(semID))';
    db.query(sql,(err,result)=>{
        if(err)
        throw err;
        console.log(result);
        res.send("Table created successfully.....");
    })
})

app.get('/createtblFeedbackInfo',(req, res)=>{
    let sql='CREATE TABLE TBLFEEDBACKINFO(feedbackID VARCHAR(10),feedback VARCHAR(10))';
    db.query(sql,(err,result)=>{
        if(err)
        throw err;
        console.log(result);
        res.send("Table created successfully.....");
    })
})


app.get('/add',(req,res)=>{
    let sql='INSERT INTO TBLSEMESTER(semID,Semester) VALUES ?';
    let VALUES=[
        ['CE_sem_5','5'],
        ['CE_sem_3','3'],
        ['CE_sem_1','1'],
        ['CE_sem_2','2'],
        ['CE_sem_6','6']

    ];
    let  query=db.query(sql,[VALUES],(err,result)=>{
        if(err)
        throw(err);     
        console.log(result);
        res.send('added Sucessfully');
    });
       
});
app.get('/addsubinfo',(req,res)=>{
    let sql='INSERT INTO tblSubjectInfo(subID,SubjectCode,SubjectName,semID) VALUES ?';
    let VALUES=[
       ['CE12','43','JAVA','CE_sem_1'],
       ['CE13','53','Python','CE_sem_5'],
       ['CE14','23','daa','CE_sem_6'],
       ['CE12','33','AI','CE_sem_3']
       ['CE1','93','BD','CE_sem_2']

    ];
    let  query=db.query(sql,[VALUES],(err,result)=>{
        if(err)
        throw(err);     
        console.log(result);
        res.send('added Sucessfully');
    });
       
});
app.get('/addfeedbackinfo',(req,res)=>{
    let sql='INSERT INTO TBLFEEDBACKINFO(feedbackID,feedback) VALUES ?';
    let VALUES=[
       ['1a','Execellent'],
       ['2a','good'],
       ['3a','Excellent'],
       ['4a',' verygood'],
       ['5a','verygood']

    ];
    let  query=db.query(sql,[VALUES],(err,result)=>{
        if(err)
        throw(err);     
        console.log(result);
        res.send('added Sucessfully');
    });
       
});

app.get('/displaySEMESTER',(req,res)=>{
    db.query('SELECT * FROM TBLSEMESTER',(err,result)=>{
        if(err)
        throw(err);
        console.log(result);
        res.send(result);
    });
});

app.get('/displaySUBINFO',(req,res)=>{
    db.query('SELECT * FROM tblSubjectInfo',(err,result)=>{
        if(err)
        throw(err);
        console.log(result);
        res.send(result);
    });
});

app.get('/subcode',(req,res)=>{
    db.query('select * from tblSubjectInfo where SUBJECT_CODE ',(err,result)=>{
        if(err)
        throw(err);
        console.log(result);
        res.send(result);
    });
});


app.get('/displayFEEDBACK',(req,res)=>{
    db.query('select feedbackId,feedback from TBLFEEDBACKINFO ',(err,result)=>{
        if(err)
        throw(err);
        console.log(result);
        res.send(result);
    });
});

app.listen(3000,()=>{
    console.log("Server listning on port 3000");
})